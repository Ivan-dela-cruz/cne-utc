
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>
    <div id="wrapper">
        <!-- Content-->
        <div class="content">
            
                    <section class="scroll-con-sec hero-section" data-scrollax-parent="true" id="sec1">
                        <div class="bg"  data-bg="<?php echo e(asset('assets/images/principal.png')); ?>" data-scrollax="properties: { translateY: '200px' }"></div>
                      
                        <div class="hero-section-wrap fl-wrap">
                            <div class="container">
                                <div class="main-search-input-wrap">
                                      
                                     
                                       
                                </div>
                            </div>
                        </div>
                        <div class="bubble-bg"> </div>
                    </section>
                    <!-- section end -->

            <section id="sec2" class="gray-section">
                <div class="container">
                    <div class="section-title">
                        <h2>INGRESAR RESULTADOS</h2>
                        <div class="section-subtitle">Elije con responsabilidad</div>
                        <span class="section-separator"></span>
                      
                    </div>
                </div>
                <!-- carousel -->
                <div class="list-carousel fl-wrap card-listing ">
                    <!--listing-carousel-->
                    <div class="listing-carousel  fl-wrap ">
                        <!--slick-slide-item-->
                        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slick-slide-item">
                                <!-- listing-item -->
                                <div class="listing-item">
                                    <article class="geodir-category-listing fl-wrap">

                                        <div class="geodir-category-img">
                                            <img src="<?php echo e(asset($position->url_image)); ?>" alt="">
                                            <div class="overlay"></div>
                                            
                                        </div>
                                        <div class="geodir-category-content fl-wrap">
                                            <a class="listing-geodir-category" href="<?php echo e(route('redirect-route',$position->indent)); ?>">INGRESAR</a>

                                            <h3><a href="listing-single.html"><?php echo e($position->name); ?></a></h3>
                                            <p><?php echo e($position->description); ?> </p>
                                        </div>
                                    </article>
                                </div>
                                <!-- listing-item end-->
                            </div>
                            <!--slick-slide-item end-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--slick-slide-item-->

                        <!--slick-slide-item end-->
                        <!--slick-slide-item-->

                        <!--slick-slide-item end-->
                        <!--slick-slide-item-->

                        <!--slick-slide-item end-->

                    </div>
                    <!--listing-carousel end-->
                    <div class="swiper-button-prev sw-btn"><i class="fa fa-long-arrow-left"></i></div>
                    <div class="swiper-button-next sw-btn"><i class="fa fa-long-arrow-right"></i></div>
                </div>
                <!--  carousel end-->
            </section>
            <!-- section end -->

            <!--section -->
            
            <!-- section end -->
        </div>
        <!-- Content end -->
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/web/index.blade.php ENDPATH**/ ?>
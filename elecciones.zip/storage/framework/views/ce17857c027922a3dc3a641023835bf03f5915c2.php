
<?php $__env->startSection('title','Candidates'); ?>
<?php $__env->startSection('position'); ?>
<div class="breadcrumbs">
    <a href="<?php echo e(route('admin')); ?>">Home</a>
    <span>Dashboard</span>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <div class="profile-edit-container">    
            <div class="statistic-container fl-wrap">
               
                <div class="statistic-item-wrap">
                    <div class="statistic-item gradient-bg fl-wrap">
                        <i class="fa fa-list-alt"></i>
                        <div class="statistic-item-numder"><?php echo e($positions); ?></div>
                        <h5>Cargos</h5>
                    </div>
                </div>
                <div class="statistic-item-wrap">
                    <div class="statistic-item gradient-bg fl-wrap">
                        <i class="fa fa-address-card"></i>
                        <div class="statistic-item-numder"><?php echo e($organizations); ?></div>
                        <h5>Organizaciones</h5>
                    </div>
                </div>
                <div class="statistic-item-wrap">
                    <div class="statistic-item gradient-bg fl-wrap">
                        <i class="fa fa-calendar-check-o"></i>
                        <div class="statistic-item-numder"><?php echo e($enclosures); ?></div>
                        <h5>Recintos</h5>
                    </div>
                </div>
                <div class="statistic-item-wrap">
                    <div class="statistic-item gradient-bg fl-wrap">
                        <i class="fa fa fa-id-card-o"></i>
                        <div class="statistic-item-numder"><?php echo e($candidates); ?></div>
                        <h5>Candidatos</h5>
                    </div>
                </div>
                <div class="statistic-item-wrap">
                    <div class="statistic-item gradient-bg fl-wrap">
                        <i class="fa fa-newspaper-o"></i>
                        <div class="statistic-item-numder"><?php echo e($electores); ?></div>
                        <h5>Electores</h5>
                    </div>
                </div>
                <div class="statistic-item-wrap">
                    <div class="statistic-item gradient-bg fl-wrap">
                        <i class="fa fa-user-circle-o"></i>
                        <div class="statistic-item-numder"><?php echo e($users); ?></div>
                        <h5>Usuarios</h5>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/init/dashboard.blade.php ENDPATH**/ ?>
<label>Nombre <i class="fa fa-user-o"></i></label>
<?php echo e(Form::text('name', null, ['class' => '', 'id' => 'name'])); ?>

<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<strong class="text-danger"><?php echo e($message); ?></strong>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<label>Descipción <i class="fa fa-user-o"></i></label>
<?php echo e(Form::text('description', null, ['class' => '', 'id' => 'description'])); ?>

<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<strong class="text-danger"><?php echo e($message); ?></strong>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="dashboard-list-box fl-wrap activities">
        <div class="dashboard-header fl-wrap">
            <h3><?php echo e($permission); ?></h3>
        </div>
        <div class="dashboard-list">
            <div class="dashboard-message">
                <div class="dashboard-message-text">
                    <div class="row">
                        <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <label>
                                    <?php echo e(Form::checkbox('permissions[]', $p->id)); ?> <?php echo e($p->name); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<button type="submit" class="btn  big-btn  color-bg flat-btn">Guardar<i
        class="fa fa-angle-right"></i></button>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/roles/partials/form.blade.php ENDPATH**/ ?>
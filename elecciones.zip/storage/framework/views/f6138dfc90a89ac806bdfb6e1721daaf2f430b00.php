<div class="col-md-3">
    <div class="fixed-bar fl-wrap">
        <div class="user-profile-menu-wrap fl-wrap">
            <!-- user-profile-menu-->
            <div class="user-profile-menu">
                <h3>Principales</h3>
                <ul>
                    <li>
                        <a class="<?php echo e((request()->is('admin')) ? 'user-profile-act' : ''); ?>"
                           href="<?php echo e(route('admin')); ?>"><i
                                class="fa fa-desktop"></i>Dashboard</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read_position')): ?>
                        <li>
                            <a class="<?php echo e((request()->is('dashboard/positions')) ? 'user-profile-act' : ''); ?>"
                               href="<?php echo e(route('positions.index')); ?>"><i
                                    class="fa fa-hand-grab-o"></i>Cargos</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read_organization')): ?>
                        <li>
                            <a class="<?php echo e((request()->is('dashboard/organizations')) ? 'user-profile-act' : ''); ?>"
                               href="<?php echo e(route('organizations.index')); ?>"><i
                                    class="fa fa-address-card"></i>Organizaciones</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read_candidate')): ?>
                        <li>
                            <a class="<?php echo e((request()->is('dashboard/candidates')) ? 'user-profile-act' : ''); ?>"
                               href="<?php echo e(route('candidates.index')); ?>"><i
                                    class="fa fa-user-o"></i> Candidatos</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read_enclosure')): ?>
                        <li>
                            <a class="<?php echo e((request()->is('dashboard/enclosures')) ? 'user-profile-act' : ''); ?>"
                               href="<?php echo e(route('enclosures.index')); ?>">
                                <i
                                    class="fa fa-calendar-check-o"></i> Recintos</a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read_location')): ?>
                        <li>
                            <a class="<?php echo e((request()->is('dashboard/locations')) ? 'user-profile-act' : ''); ?>"
                               href="<?php echo e(route('locations.index')); ?>"><i
                                    class="fa fa-th-list"></i>
                                Ubicaciones </a></li> <?php endif; ?>

                </ul>
            </div>
            <!-- user-profile-menu end-->
            <!-- user-profile-menu-->
            <div class="user-profile-menu">
                <h3>Configuración</h3>
                <ul>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read_user')): ?>
                        <li>
                            <a class="<?php echo e((request()->is('dashboard/users')) ? 'user-profile-act' : ''); ?>"
                               href="<?php echo e(route('users.index')); ?>"><i
                                    class="fa fa-user"></i>Usuarios</a></li>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin')): ?>
                    <li>
                        <a class="<?php echo e((request()->is('dashboard/roles')) ? 'user-profile-act' : ''); ?>"
                           href="<?php echo e(route('roles.index')); ?>"><i
                                class="fa fa-universal-access"></i>
                            Roles</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read_user')): ?>
                        <li>
                            <a class="<?php echo e((request()->is('dashboard/change-my-password')) ? 'user-profile-act' : ''); ?>"
                               href="<?php echo e(route('change-my-password')); ?>">
                                <i
                                    class="fa fa-unlock-alt"></i> Contraseñas</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <!-- user-profile-menu end-->
            <a class="log-out-btn" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                Salir
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/init/sidebar.blade.php ENDPATH**/ ?>
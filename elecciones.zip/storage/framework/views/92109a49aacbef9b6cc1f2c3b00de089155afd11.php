
<?php if(isset($positions)): ?>
<?php if(count($positions)>0): ?>
    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
        <option value="<?php echo e($position->indent); ?>"><?php echo e($position->name); ?></option>
       
 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <option value="0">No hay dignidades que mostrar</option>
<?php endif; ?>
 
<?php else: ?>
<option value="0">No hay dignidades que mostrar</option>
<?php endif; ?><?php /**PATH C:\laragon\www\elecciones\resources\views/web/selects/positions.blade.php ENDPATH**/ ?>
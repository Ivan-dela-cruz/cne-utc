<table id="customers">
    <thead>
        <tr >
            <th >Recinto</th>
            <th >Femenina</th>
            <th >Masculino</th>
            <th >Total</th>
            <th >Electores</th>
            <th >zona</th>
            <th >Parroquia</th>
            <th colspan="2">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $enclosures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enclosure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td ><?php echo e($enclosure->name); ?></td>
            <td ><?php echo e($enclosure->meeting_fem); ?></td>
            <td ><?php echo e($enclosure->meeting_mas); ?></td>
            <td ><?php echo e($enclosure->meeting_total); ?></td>
            <td ><?php echo e($enclosure->voters); ?></td>
            <td ><?php echo e($enclosure->zone); ?></td>
            <td ><?php echo e($enclosure->location->name); ?></td>
            <td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_enclosure')): ?>
                <a class="edit-btn" href="<?php echo e(route('enclosures.edit',$enclosure->id)); ?>"> <i class="fa fa-pencil-square-o"></i></a>
                <?php endif; ?>
            </td>
            <td>
                <?php echo Form::open(['route' => ['enclosures.destroy', $enclosure->id], 'method' => 'DELETE','class'=>'delete-item'.$enclosure->id]); ?>

                   
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy_enclosure')): ?> 
                <button  data-id="<?php echo e($enclosure->id); ?>"  class="del-btn delete-item-table" type="submit"><i class="fa fa-trash-o"></i></button>
                <?php endif; ?>
                <?php echo Form::close(); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
    </tbody>
</table>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/enclosures/tabla.blade.php ENDPATH**/ ?>
<div class="col-md-7">
    <div class="profile-edit-container">
        <div class="profile-edit-header fl-wrap">
            <?php if(isset($user)): ?>
                <h4> Editar usuario </h4>
            <?php else: ?>
                <h4> Nuevo usuario </h4>
            <?php endif; ?>
        </div>
        <div class="custom-form">
            <label>Nombre <i class="fa fa-user-o"></i></label>
            <?php echo Form::text('name',null, ['id'=>'name']); ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Apellidos<i class="fa fa-envelope-o"></i> </label>
            <?php echo Form::text('last_name',null, ['id'=>'last_name']); ?>

            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Usuario<i class="fa fa-envelope-o"></i> </label>
            <?php echo Form::text('username',null, ['id'=>'username']); ?>

            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Dirección<i class="fa fa-envelope-o"></i> </label>
            <?php echo Form::text('address',null, ['id'=>'address']); ?>

            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Télefono<i class="fa fa-envelope-o"></i> </label>
            <?php echo Form::text('phone',null, ['id'=>'phone']); ?>

            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Email<i class="fa fa-envelope-o"></i> </label>
            <?php echo Form::text('email',null, ['id'=>'email']); ?>

            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php if(!isset($user)): ?>
                <div class="custom-form no-icons">
                    <div class="pass-input-wrap fl-wrap">
                        <label>Contraseña</label>
                        <?php echo Form::password('password',null, ['id'=>'password','class'=>'pass-input']); ?>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <span class="eye"><i class="fa fa-eye" aria-hidden="true"></i> </span>
                    </div>
                    <div class="pass-input-wrap fl-wrap">
                        <label>Confirmar Contraseña</label>
                        <?php echo Form::password('confirm_password',null, ['id'=>'confirm_password','class'=>'pass-input']); ?>

                        <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <span class="eye"><i class="fa fa-eye" aria-hidden="true"></i> </span>
                    </div>
                </div>
            <?php endif; ?>
            <div class="dashboard-list-box fl-wrap activities">
                <div class="dashboard-header fl-wrap">
                    <h3>Roles</h3>
                </div>
                <div class="dashboard-list">
                    <div class="dashboard-message">
                        <div class="dashboard-message-text">
                            <div class="row">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <label>
                                            <?php echo e(Form::checkbox('roles[]', $role->id)); ?> <?php echo e($role->name); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn  big-btn  color-bg flat-btn">Guardar<i
                    class="fa fa-angle-right"></i></button>
        </div>
    </div>
</div>
<div class="col-md-2">
    <div class="edit-profile-photo fl-wrap">
        <?php if(isset($user)): ?>
            <img src="<?php echo e(asset($user->url_image)); ?>" class="respimg" alt="">
        <?php else: ?>
            <img src="<?php echo e(asset('assets/images/avatar/1.jpg')); ?>" class="respimg" alt="">
        <?php endif; ?>
        <div class="change-photo-btn">
            <div class="photoUpload">
                <span><i class="fa fa-upload"></i> Subir foto</span>
                <?php echo Form::file('image', ['id'=>'image','class'=>'upload']); ?>

                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/users/partials/form.blade.php ENDPATH**/ ?>
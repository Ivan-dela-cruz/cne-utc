<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="dashboard-list">
        <div class="dashboard-message">
            <div class="dashboard-listing-table-image">
                <a href="listing-single.html"><img src="<?php echo e(asset($user->avatar)); ?>" alt=""></a>
            </div>
            <div class="dashboard-listing-table-text">
                <h4><a href="listing-single.html"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></a></h4>
                
                <ul class="dashboard-listing-table-opt  fl-wrap">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_user')): ?> 
                      <li><a href="<?php echo e(route('users.edit',$user->id)); ?>">Edit <i class="fa fa-pencil-square-o"></i></a></li>
                      <?php endif; ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy_user')): ?> <li><a href="#" class="del-btn">Delete <i class="fa fa-trash-o"></i></a></li>
                      <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/users/table.blade.php ENDPATH**/ ?>
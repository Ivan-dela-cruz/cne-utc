<script type="text/javascript" src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/js/plugins.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/js/scripts.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(url('js/all_admin.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/axios.min.js')); ?>"></script>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/init/js.blade.php ENDPATH**/ ?>
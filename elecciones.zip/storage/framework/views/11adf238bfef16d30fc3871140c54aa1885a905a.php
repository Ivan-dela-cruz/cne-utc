
<?php $__env->startSection('title','candidates'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo Form::open(['url' => route('candidates.store'), 'method' => 'post','files'=>true]); ?>

    <?php echo $__env->make('admin.candidates.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/candidates/create.blade.php ENDPATH**/ ?>
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/reset.css')); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/color.css')); ?>">

<!--=============== favicons ===============-->
<link rel="shortcut icon" href="images/favicon.ico">
<?php /**PATH C:\laragon\www\elecciones\resources\views/web/init/css.blade.php ENDPATH**/ ?>
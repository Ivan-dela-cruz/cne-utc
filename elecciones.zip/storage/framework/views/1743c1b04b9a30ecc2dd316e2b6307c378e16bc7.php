<?php if(isset($meetings)): ?>
    <?php if(isset($meetings)): ?>
        <?php for($i = 0; $i <$meetings; $i++): ?>
        <option  value="<?php echo e($i+1); ?>"><?php echo e($i+1); ?></option>
        <?php endfor; ?>
    <?php else: ?>
        <option value="0">0</option>
    <?php endif; ?>
<?php else: ?>
<option value="0">N/A</option>
<?php endif; ?>

     <?php /**PATH C:\laragon\www\elecciones\resources\views/web/selects/meeting.blade.php ENDPATH**/ ?>
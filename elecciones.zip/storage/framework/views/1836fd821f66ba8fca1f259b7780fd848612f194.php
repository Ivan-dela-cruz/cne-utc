<header class="main-header dark-header fs-header sticky">
    <div class="header-inner">
        <div class="header-inner">
            <div class="logo-holder">
                <a style="color: white; font-size: 20px;" href="<?php echo e(url('/')); ?>"><img
                        src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                    <b> Elecciones 2021</b> </a>
            </div>

                <?php if(auth()->guard()->guest()): ?>
            
                
                <?php else: ?>
                <div class="header-user-menu">
                    <div class="header-user-name">
                        <span><img src="<?php echo e(asset('assets/images/avatar/avatar-bg.png')); ?>" alt=""></span>
                        Hola, <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>

                    </div>
                    <ul>
                        <li><a href="dashboard-myprofile.html"> Mi perfil</a></li>
                        <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">Cerrar sesión</a>
                        </li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </ul>
                      </div>
                <?php endif; ?>

          
           

        <!-- nav-button-wrap-->
            <div class="nav-button-wrap color-bg">
                <div class="nav-button">
                    <span></span><span></span><span></span>
                </div>
            </div>
            <!-- nav-button-wrap end-->
            <!--  navigation -->
            <div class="nav-holder main-menu">
                <nav>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('webster')); ?>">Webster</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('results')); ?>">Resultados</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>

                    </ul>
                </nav>
            </div>
            <!-- navigation  end -->
        </div>
</header>
<?php /**PATH C:\laragon\www\elecciones\resources\views/web/init/header.blade.php ENDPATH**/ ?>
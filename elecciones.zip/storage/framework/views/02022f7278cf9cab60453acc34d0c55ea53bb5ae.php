
<?php $__env->startSection('title','Editar Candidato'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo Form::model($candidate,['url' => route('candidates.update',$candidate->id), 'method' => 'PUT','files'=>true]); ?>

    <?php echo $__env->make('admin.candidates.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/candidates/edit.blade.php ENDPATH**/ ?>
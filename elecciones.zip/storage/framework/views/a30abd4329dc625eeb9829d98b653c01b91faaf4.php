
<?php $__env->startSection('title','Crear cargo'); ?>
<?php $__env->startSection('position'); ?>
<div class="breadcrumbs">
    <a href="<?php echo e(route('admin')); ?>">Home</a>
    <a href="<?php echo e(route('positions.index')); ?>">Dignidades</a>
    <span>Nuevo</span>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php echo Form::open(['url' => route('positions.store'),'files' => true]); ?>

    <?php echo $__env->make('admin.positions.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/positions/create.blade.php ENDPATH**/ ?>
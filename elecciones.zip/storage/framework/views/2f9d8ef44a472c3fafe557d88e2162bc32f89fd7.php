
<?php $__env->startSection('title','Editar usuario'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo Form::model($user,['url' => route('users.update',$user->id),'method' => 'PUT','files' => true]); ?>

    <?php echo $__env->make('admin.users.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>
<div class="col-md-7">
    <div class="profile-edit-container">
        <div class="profile-edit-header fl-wrap">
            <?php if(isset($candidate)): ?>
                <h4>Editar Candidato</h4>
            <?php else: ?>
                <h4>Nuevo Candidato</h4>
            <?php endif; ?>

        </div>
        <div class="custom-form">

            <label>Nombre <i class="fa fa-user-o"></i></label>
            <?php echo Form::text('name', null,['id'=>'name']); ?>


            <label> Apellido <i class="fa fa-globe"></i> </label>
            <?php echo Form::text('last_name', null,['id'=>'last_name']); ?>


            <label> Partido politico <i class="fa fa-globe"></i> </label>
            <?php echo Form::select('organization_id', $organizations , null , ['class' => 'chosen-select']); ?>


            <label> Cargo: <i class="fa fa-globe"></i> </label>
            <?php echo Form::select('position_id', $positions , null , ['class' => 'chosen-select']); ?>

            <label>Inicio de Cargo<i class="fa fa-calendar-check-o"></i></label>
            <input name="start_date" type="text" placeholder="Date" class="datepicker"   data-large-mode="true" data-large-default="true" value=""/>
            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label>Fin de Cargo<i class="fa fa-calendar-check-o"></i>  </label>
            <input name="end_date" type="text" placeholder="Date" class="datepicker"   data-large-mode="true" data-large-default="true" value=""/>
            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit" class="btn  big-btn  color-bg flat-btn">Guardar<i
                    class="fa fa-angle-right"></i></button>
        </div>
    </div>
</div>

<div class="col-md-2">
    <div class="edit-profile-photo fl-wrap">
        <?php if(isset($candidate)): ?>
            <img id="show_img" src="<?php echo e(asset($candidate->url_image)); ?>" class="respimg" alt="">
        <?php else: ?>
            <img id="show_img" src="<?php echo e(asset('assets/images/avatar/1.jpg')); ?>" class="respimg" alt="">
        <?php endif; ?>


        <div class="change-photo-btn">
            <div class="photoUpload">
                <span><i class="fa fa-upload"></i> Upload Photo</span>
                <?php echo Form::file('image', ['id'=>'url_image','class' => 'upload']); ?>

            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/candidates/partials/form.blade.php ENDPATH**/ ?>
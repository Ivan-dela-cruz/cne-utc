
<?php $__env->startSection('title','Enclousure'); ?>
<?php $__env->startSection('position'); ?>
<div class="breadcrumbs">
    <a href="<?php echo e(route('admin')); ?>">Home</a>
    <a href="<?php echo e(route('enclosures.index')); ?>">Recintos</a>
    <span>Listado</span>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <?php if(session('status')): ?>
            <?php if(session('status')!="error"): ?>
                <div class="notification success fl-wrap">
                    <p><?php echo e(session('status')); ?></p>
                    <a class="notification-close" href="javascript:void(0);"><i class="fa fa-times"></i></a>
                </div>
            <?php else: ?>
                <div class="notification reject fl-wrap">
                    <p>Error al realizar la petición</p>
                    <a class="notification-close" href="javascript:void(0);"><i class="fa fa-times"></i></a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="dashboard-list-box fl-wrap">
            <div class="dashboard-header fl-wrap">
                <div style="margin-top: 0px; margin-bottom: 10px; margin-left: -20px;" class="header-search">
                
                    <?php echo Form::open(['url' => route('enclosures.index'), 'method'=>'GET','autocomplete'=>'off','role'=>'search']); ?>

                    
                    <div style="width: 50%;" class="header-search-input-item">
                        <input style="width: 100%;"   <?php if(isset($keyword)): ?> value="<?php echo e($keyword); ?>" <?php endif; ?>
                        type="text" placeholder="Buscar recintos" name="keyword"/>
                    </div>
                    <button type="submit" class="header-search-button" >Buscar</button>
                    <?php echo Form::close(); ?>

                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_enclosure')): ?>
                <a href="<?php echo e(route('enclosures.create')); ?>" class="new-dashboard-item">Nuevo</a>
                <?php endif; ?>
            </div>
            
            
        </div>
        <?php if(count($enclosures)>0): ?>
            <div class="container-table">
                <?php echo $__env->make('admin.enclosures.tabla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php echo e($enclosures->links()); ?>

        
        <?php else: ?>
        <div class="text-center">
            <img height="320" src="<?php echo e(asset('assets/images/select.jpg')); ?>" alt="">
            <?php if(isset($keyword)): ?>
                <h6>No se hallaron resultados para <b> "<?php echo e($keyword); ?>"</b> </h6>
            <?php endif; ?>
            
        </div>
        <?php endif; ?>

       
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/enclosures/index.blade.php ENDPATH**/ ?>
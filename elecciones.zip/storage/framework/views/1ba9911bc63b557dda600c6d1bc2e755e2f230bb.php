
<?php $__env->startSection('title','Roles'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <div class="dashboard-list-box fl-wrap">
            <div class="dashboard-header fl-wrap">
                <h3>Roles</h3>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_rol')): ?>
                <span class="new-dashboard-item"><a href="<?php echo e(route('roles.create')); ?>">Nuevo</a></span>
                <?php endif; ?>
            </div>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dashboard-list">
                    <div class="dashboard-message">
                        <div class="dashboard-listing-table-text">
                            <h4><a href="listing-single.html"><?php echo e($role->name); ?></a></h4>
                            <span class="dashboard-listing-table-address"><i class="fa fa-map-marker"></i><a href="#">USA 27TH Brooklyn NY</a></span>
                            <div class="listing-rating card-popup-rainingvis fl-wrap" data-starrating2="5">
                                <span>(2 reviews)</span>
                            </div>
                            <ul class="dashboard-listing-table-opt  fl-wrap">
                                <li><a href="<?php echo e(route('roles.edit',$role->id)); ?>">Edit <i class="fa fa-pencil-square-o"></i></a></li>
                                <li><a href="#" class="del-btn">Delete <i class="fa fa-trash-o"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>
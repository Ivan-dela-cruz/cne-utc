<!DOCTYPE HTML>
<html lang="en">
<head>
    <!--=============== basic  ===============-->
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="robots" content="index, follow"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>
    <?php echo $__env->make('admin.init.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
<!-- loader -->
<div class="loader-wrap">
    <div class="pin"></div>
    <div class="pulse"></div>
</div>
<!--  loader end -->
<!-- Main   -->
<div id="main">
    <!-- header  -->
    <header class="main-header dark-header fs-header sticky">
        <div class="header-inner">
            <div class="logo-holder">
                <a style="color: white; font-size: 20px;" href="<?php echo e(route('admin')); ?>"><img
                        src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                    <b> Elecciones 2021</b> </a>
            </div>

            <div class="header-user-menu">
                <?php if(auth()->guard()->guest()): ?>
                    <div class="header-user-name">
                        USER NOT FOUT
                    </div>
                <?php else: ?>
                    <div class="header-user-name">
                        <span><img src="<?php echo e(asset(\Illuminate\Support\Facades\Auth::user()->avatar)); ?>" alt=""></span>
                        Hola, <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>

                    </div>
                    <ul>
                        <li><a href="<?php echo e(route('profile')); ?>"> Mi perfil</a></li>
                        <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">Cerrar sesión</a>
                        </li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </ul>
                <?php endif; ?>

            </div>
            <!-- nav-button-wrap-->
            <div class="nav-button-wrap color-bg">
                <div class="nav-button">
                    <span></span><span></span><span></span>
                </div>
            </div>
            <!-- nav-button-wrap end-->
            <!--  navigation -->
            <div class="nav-holder main-menu">
                <nav>
                    <ul>
                        
                    </ul>
                </nav>
            </div>
            <!-- navigation  end -->
        </div>
    </header>
    <!--  header end -->
    <!-- wrapper -->
    <div id="wrapper">
        <!--content -->
        <div class="content">
            <!--section -->
            <section>
                <!-- container -->
                <div class="container">
                    <!-- profile-edit-wrap -->
                    <div class="profile-edit-wrap">
                        <div class="profile-edit-page-header">
                            <h2>Panel de Control</h2>
                            <?php echo $__env->yieldContent('position'); ?>
                        </div>
                       
                        <div class="row panel-height">
                            <?php echo $__env->make('admin.init.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                    <!--profile-edit-wrap end -->
                </div>
                <!--container end -->
            </section>
            <!-- section end -->
            <div class="limit-box fl-wrap"></div>
            <!--section -->

            <!-- section end -->
        </div>
    </div>
    <!-- wrapper end -->
   
    <a class="to-top"><i class="fa fa-angle-up"></i></a>
</div>
<!-- Main end -->

<?php echo $__env->make('admin.init.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/init/index.blade.php ENDPATH**/ ?>
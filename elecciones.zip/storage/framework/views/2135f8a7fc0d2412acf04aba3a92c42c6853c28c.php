<table class="table table-striped table-bordered table-hover table-dark">
    <thead>
        <tr>
            <th>Información</th>
            <th>Total</th>
            <th>Hombres</th>
            <th>Mujeres</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>NÚMERO DE ELECTORES</td>
            <td><?php echo e($data['voters']); ?></td>
            <td><?php echo e($data['voters_mas']); ?></td>
            <td><?php echo e($data['voters_fem']); ?></td>
        </tr>
        <tr>
            <td>JUNTAS RECEPTORAS</td>
            <td><?php echo e($data['total']); ?></td>
            <td><?php echo e($data['mas']); ?></td>
            <td><?php echo e($data['fem']); ?></td>
        </tr>
        <tr>
            <td>VOTOS VÁLIDOS</td>
            <td><?php echo e($vote_t); ?></td>
            <td><?php echo e($vote_tmas); ?></td>
            <td><?php echo e($vote_tfem); ?></td>
        </tr>
        <tr>
            <td>VOTOS EN BLANCO</td>
            <td><?php echo e($vote_b); ?></td>
            <td><?php echo e($vote_bmas); ?></td>
            <td><?php echo e($vote_bfem); ?></td>
        </tr>
        <tr>
            <td>VOTOS NULOS</td>
            <td><?php echo e($vote_n); ?></td>
            <td><?php echo e($vote_nmas); ?></td>
            <td><?php echo e($vote_nfem); ?></td>
        </tr>
    </tbody>
</table><?php /**PATH C:\laragon\www\elecciones\resources\views/web/results/resum.blade.php ENDPATH**/ ?>
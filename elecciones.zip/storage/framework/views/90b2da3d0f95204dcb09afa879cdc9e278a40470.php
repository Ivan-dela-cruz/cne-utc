
<link type="text/css" rel="stylesheet" href="<?php echo e(url('assets/css/reset.css')); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo e(url('assets/css/plugins.css')); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
<link type="text/css" rel="stylesheet" href="<?php echo e(url('assets/css/color.css')); ?>">

<!--=============== favicons ===============-->
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/init/css.blade.php ENDPATH**/ ?>
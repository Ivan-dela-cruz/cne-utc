
<?php if(isset($parishes)): ?>
    <?php if(count($parishes)>0): ?>

        <?php $__currentLoopData = $parishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($parish->id); ?>"><?php echo e($parish->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <option value="0">No hay parroquias que mostrar</option>
    <?php endif; ?>
<?php else: ?>
<option value="0">No hay parroquias que mostrar</option>
<?php endif; ?>

<?php /**PATH C:\laragon\www\elecciones\resources\views/web/selects/parishes.blade.php ENDPATH**/ ?>
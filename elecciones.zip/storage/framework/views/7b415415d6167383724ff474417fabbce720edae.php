
<?php $__env->startSection('title','Positions'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <div class="dashboard-list-box fl-wrap">
            <div class="dashboard-header fl-wrap">
                <h3>Indox</h3>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_position')): ?>
                  <a  href="<?php echo e(route('positions.create')); ?>" class="new-dashboard-item">Nuevo</a>
                <?php endif; ?>
            </div>
            <?php echo $__env->make('admin.positions.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/positions/index.blade.php ENDPATH**/ ?>
<div class="col-md-7">
    <div class="profile-edit-container">
        <div class="profile-edit-header fl-wrap">
            <?php if(isset($location)): ?>
                <h4>Editar Ubicación</h4>
            <?php else: ?>
                <h4>Nueva Ubicación</h4>
            <?php endif; ?>

        </div>
        <div class="custom-form">
            <label> Código <i class="fa fa-globe"></i> </label>
            <?php echo Form::text('code', null,['id'=>'last_name']); ?>

            <label> Tipo: <i class="fa fa-globe"></i> </label>
            <?php echo Form::select('type', [
                    '1'=>'Provincia',
                    '2'=>'Cantón',
                    '3'=>'Parroquia'
            ] , null , ['class' => 'chosen-select']); ?>

            <label> Provincia: <i class="fa fa-globe"></i> </label>
            <?php echo Form::select('provincie_id',$provinces, null , ['class' => 'chosen-select']); ?>

            <label> Cantón: <i class="fa fa-globe"></i> </label>
            <?php echo Form::select('canton_id',$cantons, null , ['class' => 'chosen-select']); ?>

            <label>Nombre <i class="fa fa-user-o"></i></label>
            <?php echo Form::text('name', null,['id'=>'name']); ?>


            <label> Nombre completo <i class="fa fa-globe"></i> </label>
            <?php echo Form::text('long_name', null,['id'=>'last_name']); ?>


            <button type="submit" class="btn  big-btn  color-bg flat-btn">Guardar<i
                    class="fa fa-angle-right"></i></button>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/locations/partials/form.blade.php ENDPATH**/ ?>
<?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dashboard-list">
                    <div class="dashboard-message">
                        
                        <div class="dashboard-listing-table-image">
                            <a href="listing-single.html"><img src="<?php echo e(asset($position->url_image)); ?>" alt=""></a>
                        </div>
                        <div class="dashboard-listing-table-text">
                            <div class="row">
                                        <h4><span><?php echo e($position->name); ?></span></h4>
                                        <div class="booking-details fl-wrap">
                                            <span class="booking-title">Descripciòn</span> :
                                            <span class="booking-text"><a href="listing-sinle.html"><?php echo e($position->description); ?></a></span>
                                        </div>
                                        <div class="booking-details fl-wrap">
                                            <span class="booking-title">Inicio de Cargo: </span> : 
                                            <span class="booking-text"><?php echo e($position->start_date); ?></span>
                                        </div>
                                        <div class="booking-details fl-wrap">
                                            <span class="booking-title">Fin de Cargo</span> : 
                                            <span class="booking-text"><?php echo e($position->end_date); ?></span>
                                        </div>
                                       
                            </div>   
                            <ul class="dashboard-listing-table-opt  fl-wrap">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_position')): ?>
                                 <li><a href="<?php echo e(route('positions.edit',$position->id)); ?>">Editar <i
                                    class="fa fa-pencil-square-o"></i></a></li>
                                    <?php endif; ?>
                        <?php echo Form::open(['route' => ['positions.destroy', $position->id], 'method' => 'DELETE','class'=>'delete-item'.$position->id]); ?>

                    
                         <li><a href="#" class="btn del-btn">Eliminar <i class="fa fa-trash-o"></i></a></li>
                       
                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy_position')): ?>
                        <button type="submit">Borrar</button>
                        <?php endif; ?>
                        <?php echo Form::close(); ?>

                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/positions/table.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Editar rol'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <div class="profile-edit-container">
            <div class="profile-edit-header fl-wrap">
                <h4>Editar rol</h4>
            </div>
            <div class="custom-form">
                <?php echo Form::model($role, ['url' => route('roles.update',$role->id), 'method' => 'PUT']); ?>

                <?php echo $__env->make('admin.roles.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>
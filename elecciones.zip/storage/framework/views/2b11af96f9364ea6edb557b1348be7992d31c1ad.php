
<?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="dashboard-list">
        <div class="dashboard-message">
            <div class="dashboard-listing-table-image">
                <a href="listing-single.html"><img src="<?php echo e(asset($province->url_image)); ?>" alt=""></a>
            </div>
            <div class="dashboard-listing-table-text">
                <div class="row">
                    <h4><?php echo e($province->name); ?></h4>
                    <div class="booking-details fl-wrap">
                        <span class="booking-title">Nombre completo:</span> :
                        <span class="booking-text"><a
                                href="listing-sinle.html"><?php echo e($province->long_name); ?></a></span>
                    </div>
                    <div class="booking-details fl-wrap">
                        <span class="booking-title">Cargo:</span> :
                        <span class="booking-text"><?php echo e($province->name); ?></span>
                    </div>
                </div>
                <ul class="dashboard-listing-table-opt  fl-wrap">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_location')): ?>
                    <li><a href="<?php echo e(route('locations.edit',$province->id)); ?>">Editar <i class="fa fa-pencil-square-o"></i></a>
                    </li>
                    <?php endif; ?>
                    <?php echo Form::open(['route' => ['locations.destroy', $province->id], 'method' => 'DELETE','class'=>'delete-item'.$province->id]); ?>

                    <li><a href="#" class="btn del-btn">Eliminar <i class="fa fa-trash-o"></i></a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy_location')): ?>
                     <button type="submit">Borrar</button>
                     <?php endif; ?>
                    <?php echo Form::close(); ?>

                </ul>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/locations/tabla.blade.php ENDPATH**/ ?>
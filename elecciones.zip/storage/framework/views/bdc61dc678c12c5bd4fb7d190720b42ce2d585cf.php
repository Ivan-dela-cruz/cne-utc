
<?php if(isset($enclosures)): ?>
    <?php if(count($enclosures)>0): ?>
        <?php $__currentLoopData = $enclosures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enclosure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($enclosure->id); ?>"><?php echo e($enclosure->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <option value="0">No hay recintos que mostrar</option>
    <?php endif; ?>
     
<?php else: ?>
<option value="0">No hay recintos que mostrar</option>
<?php endif; ?>
<?php /**PATH C:\laragon\www\elecciones\resources\views/web/selects/enclosures.blade.php ENDPATH**/ ?>
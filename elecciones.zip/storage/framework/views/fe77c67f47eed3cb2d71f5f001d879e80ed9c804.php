
<?php $__env->startSection('title','Editar Enclousure'); ?>
<?php $__env->startSection('content'); ?>

    <?php echo Form::model($enclosure,['url' => route('enclosures.update',$enclosure->id), 'method' => 'PUT','files'=>true]); ?>

    <?php echo $__env->make('admin.enclosures.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/enclosures/edit.blade.php ENDPATH**/ ?>
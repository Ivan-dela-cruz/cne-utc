<table class="table table-striped table-bordered table-hover table-dark">
    <thead>
        <tr>
            <th>Organización</th>
            <th>Votos</th>
            <th>Porcentajes</th>
        </tr>
    </thead>
    
    <tbody>
        <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($organization->organization); ?></td>
            <td><?php echo e($organization->votes); ?></td>
            <td><?php echo e(round(($organization->votes/$total)*100,2)); ?> %</td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </tbody>
</table><?php /**PATH C:\laragon\www\elecciones\resources\views/web/results/total.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Resultados'); ?>
<?php $__env->startSection('css'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/tables.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="wrapper">
        <!-- Content-->
        <div class="content">
            <section class="scroll-con-sec hero-section" data-scrollax-parent="true" id="sec1">
                <div class="bg"  data-bg="<?php echo e(asset('assets/images/principal.png')); ?>" data-scrollax="properties: { translateY: '200px' }"></div>
                <div class="hero-section-wrap fl-wrap">
                    <div class="container">
                            <div class="custom-form">
                    
                                <div  class="row block-div">
                                        
                                    <div class="col-md-3">
                                        <select data-placeholder="All Categories" class="chosen-select-canton">
                                
                                            <?php $__currentLoopData = $cantons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canton): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($canton->id); ?>"><?php echo e($canton->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
            
                                    <div class="col-md-3">
                                        <select   data-placeholder="All Categories" class="chosen-select-result">
                                                <?php echo $__env->make('web.selects.parishes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </select>
                                    </div>
                
                                    <div class="col-md-3">
                                        <select  data-placeholder="Dignidades" class="chosen-select-position">
                                        
                                            <?php echo $__env->make('web.selects.positions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
                <div class="bubble-bg"> </div>
                
            </section>
            <section >
                <div class="row ml-5 mr-5">
                    <div class="col-md-6 table_resum">
                        
                    </div>
                    <div class="col-md-6 table_total">
                        
                    </div>
                    <div style="background-color: #323539;" class="col-md-12">
                        <canvas id="myChart" style="height: 400px; width: 100%;"></canvas>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
   
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
     <script type="text/javascript" src="<?php echo e(asset('js/script_pages.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/web/results/index.blade.php ENDPATH**/ ?>
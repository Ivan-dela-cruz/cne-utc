
<?php $__env->startSection('title','Ubicaciones'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <div class="dashboard-list-box fl-wrap">
            <div class="dashboard-header fl-wrap">
                <h3>Lista de ubicaciones</h3>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_location')): ?>
                <a href="<?php echo e(route('locations.create')); ?>" class="new-dashboard-item">Nuevo</a>
                <?php endif; ?>
            </div>
            <?php echo $__env->make('admin.locations.tabla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.locations.tabla_cantons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.locations.tabla_parish', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.init.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elecciones\resources\views/admin/locations/index.blade.php ENDPATH**/ ?>
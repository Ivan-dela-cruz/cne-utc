<?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="dashboard-list">
        <div class="dashboard-message">

            <div class="dashboard-listing-table-image">
                <a href="listing-single.html"><img src="<?php echo e(asset($organization->url_image)); ?>" alt=""></a>
            </div>
            <div class="dashboard-listing-table-text">
                <div class="row">
                    <h4 class="col-md-12"><?php echo e($organization->name); ?><span> - (<?php echo e($organization->acronym); ?>)</span></h4>
                    <div class="col-md-6">
                        <div class="booking-details fl-wrap ">
                            <span class="booking-title">Lista:</span>
                            <span class="booking-text"><a href="listing-sinle.html"><?php echo e($organization->list); ?></a></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="booking-details fl-wrap">
                            <span class="booking-title">Representate:</span>
                            <span class="booking-text"><?php echo e($organization->representative); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="booking-details fl-wrap">
                            <span class="booking-title">Asambleistas:</span>
                            <span class="booking-text"><?php echo e($organization->assembly_members); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="booking-details fl-wrap">
                            <span class="booking-title">Prefectos:</span>
                            <span class="booking-text"><?php echo e($organization->prefects); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="booking-details fl-wrap">
                            <span class="booking-title">Alcaldes:</span>
                            <span class="booking-text"><?php echo e($organization->mayors); ?></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="booking-details fl-wrap">
                            <span class="booking-title">Estado:</span>
                            <span class="booking-text"><?php echo e($organization->status); ?></span>
                        </div>
                    </div>
                </div>
                <ul class="dashboard-listing-table-opt  fl-wrap">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_organization')): ?>
                    <li><a href="<?php echo e(route('organizations.edit',$organization->id)); ?>">Editar <i
                                class="fa fa-pencil-square-o"></i></a></li>
                                <?php endif; ?>
                    <?php echo Form::open(['route' => ['organizations.destroy', $organization->id], 'method' => 'DELETE','class'=>'delete-item'.$organization->id]); ?>

                   
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy_organization')): ?>
                      <button data-id="<?php echo e($organization->id); ?>"
                        class="del-btn delete-item-table"
                      type="submit">Eliminar <i class="fa fa-trash-o"></i></button>
                      <?php endif; ?>
                    <?php echo Form::close(); ?>

                </ul>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/organizations/table.blade.php ENDPATH**/ ?>
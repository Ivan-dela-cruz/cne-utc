<div class="col-md-7">
    <!-- profile-edit-container-->
    <div class="profile-edit-container">
        <div class="profile-edit-header fl-wrap">
            <h4>Nuevo Cargo</h4>
        </div>
        <div class="custom-form">
            <label> Ámbito politico <i class="fa fa-globe"></i> </label>
            <?php echo Form::select('indent', $list , null , ['class' => 'chosen-select']); ?>

            <label>Nombre <i class="fa fa-user-o"></i></label>
            <?php echo Form::text('name',null, ['id'=>'name','required'=>'required']); ?>

            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label>Descripción<i class="fa fa-envelope-o"></i> </label>
            <?php echo Form::text('description',null, ['id'=>'description','required'=>'required']); ?>

            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            

            <button type="submit" class="btn  big-btn  color-bg flat-btn">Guardar<i
                    class="fa fa-angle-right"></i></button>
        </div>
    </div>
</div>
<div class="col-md-2">
    <div class="edit-profile-photo fl-wrap">
        <?php if(isset($position)): ?>
        <img id="show_img" src="<?php echo e(asset($position->url_image)); ?>" class="respimg" alt="">
    <?php else: ?>
        <img id="show_img" src="<?php echo e(asset('assets/images/avatar/1.jpg')); ?>" class="respimg" alt="">
    <?php endif; ?>
        <div class="change-photo-btn">
            <div class="photoUpload">
                <span><i class="fa fa-upload"></i> Upload Photo</span>
                <?php echo Form::file('image', ['id'=>'url_image','class'=>'upload']); ?>

                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

</div>

<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/positions/partials/form.blade.php ENDPATH**/ ?>

<table class="table table-striped table-bordered table-hover table-dark">
    <thead>
        <tr>
            <th>ORGANIZACION</th>
            <?php for($i = 0; $i < count($series); $i++): ?>
                <td><?php echo e($series[$i]); ?></td>
            <?php endfor; ?>
           
        </tr>
    </thead>
    <tbody>
        
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($res['organization']); ?></td>
            <?php $__currentLoopData = $res['lista']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p hidden><?php echo e($cont = 0); ?></p>
                <?php $__currentLoopData = $webster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($k['votes'] == $web['votes'] ): ?>
                       <p hidden> <?php echo e($cont++); ?></p>
                        
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($cont>0): ?>
                    <td style="background-color: rgb(241, 67, 67);"><?php echo e($k['votes']); ?></td>
                <?php else: ?>
                    <td><?php echo e($k['votes']); ?></td>
                <?php endif; ?>
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\elecciones\resources\views/web/westerm/table.blade.php ENDPATH**/ ?>
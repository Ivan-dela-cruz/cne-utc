 
    <div class="sub-footer fl-wrap">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="about-widget">
                        <img src="images/logo.png" alt="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="copyright"> &#169; UTC 2020 . All rights reserved.</div>
                </div>
                <div class="col-md-4">
                    <div class="footer-social">
                        <ul>
                            <li><a href="#" target="_blank"><i class="fa fa-facebook-official"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fa fa-chrome"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fa fa-vk"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fa fa-whatsapp"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH C:\laragon\www\elecciones\resources\views/web/init/footer.blade.php ENDPATH**/ ?>
<?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="dashboard-list">
        <div class="dashboard-message">
            <div class="dashboard-listing-table-image">
                <a href="javascript:void(0);">
                    <?php if(!is_null($candidate->url_image)): ?>
                    <img style="width: 180px; height: 180px;" src="<?php echo e(asset($candidate->url_image)); ?>" alt="imagen candidato">
                    <?php else: ?>
                    <img style="width: 180px; height: 180px;" src="<?php echo e(asset('assets/images/user.png')); ?>" alt="imagen candidato">
                    <?php endif; ?>
                    
                </a>
            </div>
            <div class="dashboard-listing-table-text">
                <div class="row">
                    <h4><?php echo e($candidate->name); ?> <span> <?php echo e($candidate->last_name); ?></span></h4>
                    <div class="booking-details fl-wrap">
                        <span class="booking-title">Lista:</span> :
                        <span class="booking-text"><a
                                href="javascript:void(0);"><?php echo e($candidate->organization->name); ?></a></span>
                    </div>
                    <div class="booking-details fl-wrap">
                        <span class="booking-title">Cargo:</span> :
                        <span class="booking-text"><?php echo e($candidate->position->name); ?></span>
                    </div>
                </div>
                <ul class="dashboard-listing-table-opt  fl-wrap">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_candidate')): ?>
                    <li><a href="<?php echo e(route('candidates.edit',$candidate->id)); ?>">Editar <i class="fa fa-pencil-square-o"></i></a>
                    </li>
                    <?php endif; ?>
                    <?php echo Form::open(['route' => ['candidates.destroy', $candidate->id], 'method' => 'DELETE','class'=>'delete-item'.$candidate->id]); ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy_candidate')): ?> 
                    <button 
                    data-id="<?php echo e($candidate->id); ?>"
                    class="del-btn delete-item-table"
                    type="submit">Eliminar <i class="fa fa-trash-o"></i></button>
                    <?php endif; ?>
                    <?php echo Form::close(); ?>

                </ul>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\elecciones\resources\views/admin/candidates/tabla.blade.php ENDPATH**/ ?>
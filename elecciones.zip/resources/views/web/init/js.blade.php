<script type="text/javascript" src="{{asset('assets/js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/plugins.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/scripts.js')}}"></script>
<script type="text/javascript" src="{{asset('js/axios.min.js')}}"></script>
<script
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCleF-ZlouBtXF3CASe-9p7HklGPAlW0zc&libraries=places&callback=initAutocomplete"></script>
<script type="text/javascript" src="{{asset('assets/js/map_infobox.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/markerclusterer.js')}}"></script>
<script type="text/javascript" src="{{asset('assets/js/maps.js')}}"></script>
@yield('scripts')

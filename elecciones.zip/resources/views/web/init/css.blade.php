<link type="text/css" rel="stylesheet" href="{{asset('assets/css/reset.css')}}">
<link type="text/css" rel="stylesheet" href="{{asset('assets/css/plugins.css')}}">
<link type="text/css" rel="stylesheet" href="{{asset('assets/css/style.css')}}">
<link type="text/css" rel="stylesheet" href="{{asset('assets/css/color.css')}}">

<!--=============== favicons ===============-->
<link rel="shortcut icon" href="images/favicon.ico">

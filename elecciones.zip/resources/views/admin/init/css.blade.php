
<link type="text/css" rel="stylesheet" href="{{url('assets/css/reset.css')}}">
<link type="text/css" rel="stylesheet" href="{{url('assets/css/plugins.css')}}">
<link type="text/css" rel="stylesheet" href="{{url('assets/css/style.css')}}">
<link type="text/css" rel="stylesheet" href="{{url('assets/css/color.css')}}">

<!--=============== favicons ===============-->
<link rel="shortcut icon" href="{{asset('assets/images/favicon.ico')}}">
{{--
<link type="text/css" rel="stylesheet" href="{{url('css/sweetalert2.min')}}">---}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
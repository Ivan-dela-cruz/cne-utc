<script type="text/javascript" src="{{url('assets/js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{url('assets/js/plugins.js')}}"></script>
<script type="text/javascript" src="{{url('assets/js/scripts.js')}}"></script>

<script type="text/javascript" src="{{url('js/all_admin.js')}}"></script>
<script type="text/javascript" src="{{url('js/axios.min.js')}}"></script>
{{---
<script type="text/javascript" src="{{url('js/sweetalert2.all.min.js')}}"></script>

--}}